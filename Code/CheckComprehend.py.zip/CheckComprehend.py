import json
import boto3
def lambda_handler(event, context):
    # Checks to see if the entity recognizer has finished training
    comprehend = boto3.client('comprehend')
    print (event)
    EntityRecognizerARN = event['Input']['EntityRecognizerArn']
    response = comprehend.describe_entity_recognizer(
        EntityRecognizerArn=EntityRecognizerARN
    )
    print("Training In Progress")
    status = response["EntityRecognizerProperties"]["Status"]
    if "IN_ERROR" == status:
        print("Training Job Failed")
        return({
            'EntityRecognizerArn': EntityRecognizerARN,
            jobStatus: 'FAILED'
        })
    if "TRAINED" == status:
        print("Training Completed")
        return({
            'EntityRecognizerArn': EntityRecognizerARN,
            'jobStatus': 'COMPLETED'
        })
    return ({'EntityRecognizerArn': EntityRecognizerARN,
            'jobStatus': 'PENDING'})
