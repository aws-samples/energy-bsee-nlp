import json
import os
import csv
import boto3
import pandas as pd

def lambda_handler(event, context):
    # Uploads well locations to DynamoDB Table
    s3client = boto3.client('s3')
    s3 = boto3.resource('s3')
    print('Event:' + str(event))
    print('Event-Records:' + str(event['Records']))
    print('Event-Records-S3:'+ str(event['Records'][0]['s3']))
    print('Event-Records-S3-bucket-name:'+ str(event['Records'][0]['s3']['bucket']['name']))
    
    input_bucket = event['Records'][0]['s3']['bucket']['name']
    input_key = event['Records'][0]['s3']['object']['key']
    
    os.chdir('/tmp/')
    
    input_file_list = input_key.split('/')
    input_file = input_file_list[1]
    input_file_path = '/tmp/' + str(input_file)
    
    print("File:" + str(input_file))
    print("File Path" + '/tmp/' + str(input_file))
    
    #response = s3client.get_object(Bucket=input_bucket, Key=input_key)
    s3client.download_file(input_bucket, input_key, input_file_path)
    os.chdir('/tmp/')
    dynamo = boto3.resource('dynamodb')
    table = dynamo.Table(os.environ['DynamoDbTable'])
    well_activity = pd.read_csv(input_file, delimiter = ',')
    for index, row in well_activity.iterrows():
        try:
            print ('API_Well_Number: ' + str(row['API_WELL_NUMBER']))
            response = table.put_item(
                    Item={'API_WELL_NUMBER':str(row['API_WELL_NUMBER']),
                        'SURF_LATITUDE':str(row['SURF_LATITUDE']),
                        'SURF_LONGITUDE':str(row['SURF_LONGITUDE']),
                        'COMPANY_NAME':str(row['COMPANY_NAME'])
                        })
        except Exception as e:
            print (e)
    return {
        'Message': 'success'
    }                
